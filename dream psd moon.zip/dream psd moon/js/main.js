$(document).ready(function(){

    /*---------------------
     TOP Menu Stick
     --------------------- */
    var s = $("#site-navigation");
    var pos = s.position();
    $(window).scroll(function () {
        var windowpos = $(window).scrollTop();
        if (windowpos > pos.top) {
            s.addClass("stick");
        } else {
            s.removeClass("stick");
        }
    });
     	

// typed js

    new Typed('#typed', {
        stringsElement: '#typed-strings',
        typeSpeed:100,
    });


// wow

    new WOW().init();


// prettyPhoto

$("a[rel^='prettyPhoto']").prettyPhoto();



// owlCarousel
 $(".owl-carousel").owlCarousel({
     items:2,
        itemsDesktop:[1000,2],
        itemsDesktopSmall:[980,2],
        itemsTablet:[768,2],
        itemsMobile:[650,1],
        pagination:true,
        navigation:false,
        slideSpeed:1000,
        autoPlay:true
 });




// back to top
   dyscrollup.init({
        showafter : '50',
       
   });

 

/*---------------------
     on page nav
     --------------------- */
    $('.nav, .slide').onePageNav({
        currentClass: 'current',
        changeHash: true,
        scrollSpeed: 1500,
        scrollThreshold: 0.5,
        filter: ':not(.external)',
        easing: 'swing',
        begin: function () {
            //I get fired when the animation is starting
        },
        end: function () {
            //I get fired when the animation is ending
        },
        scrollChange: function (jQuerycurrentListItem) {
            //I get fired when you enter a section and I pass the list item of the section
        }
    });
   




});




